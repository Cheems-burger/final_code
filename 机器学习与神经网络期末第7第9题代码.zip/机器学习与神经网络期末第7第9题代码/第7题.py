import numpy as np
import matplotlib.pyplot as plt
from sklearn import datasets
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
import tensorflow as tf
from tensorflow import keras
import time

# 1. 数据准备
print("正在加载Iris数据集...")
iris = datasets.load_iris()
X = iris.data
y = iris.target

print(f"数据集信息:")
print(f"样本数: {X.shape[0]}")
print(f"特征数: {X.shape[1]}")
print(f"类别数: {len(np.unique(y))}")

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.3, random_state=42
)

scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# 2. SVM模型实现
print("\nSVM模型训练中...")

start_time = time.time()
svm_model = SVC(kernel='rbf', C=1.0, random_state=42)
svm_model.fit(X_train_scaled, y_train)
svm_train_time = time.time() - start_time

start_time = time.time()
y_pred_svm = svm_model.predict(X_test_scaled)
svm_pred_time = time.time() - start_time

svm_accuracy = accuracy_score(y_test, y_pred_svm)

print(f"SVM训练时间: {svm_train_time:.4f}秒")
print(f"SVM预测时间: {svm_pred_time:.4f}秒")
print(f"SVM准确率: {svm_accuracy:.4f}")

# 3. 神经网络模型实现
print("\n神经网络模型训练中...")

tf.random.set_seed(42)

nn_model = keras.Sequential([
    keras.layers.Dense(32, activation='relu', input_shape=(4,)),
    keras.layers.Dropout(0.3),
    keras.layers.Dense(16, activation='relu'),
    keras.layers.Dense(3, activation='softmax')
])

nn_model.compile(
    optimizer='adam',
    loss='sparse_categorical_crossentropy',
    metrics=['accuracy']
)

start_time = time.time()
history = nn_model.fit(
    X_train_scaled, y_train,
    epochs=100,
    batch_size=8,
    validation_split=0.2,
    verbose=0
)
nn_train_time = time.time() - start_time

start_time = time.time()
y_pred_nn_prob = nn_model.predict(X_test_scaled, verbose=0)
y_pred_nn = np.argmax(y_pred_nn_prob, axis=1)
nn_pred_time = time.time() - start_time

nn_accuracy = accuracy_score(y_test, y_pred_nn)

print(f"神经网络训练时间: {nn_train_time:.4f}秒")
print(f"神经网络预测时间: {nn_pred_time:.4f}秒")
print(f"神经网络准确率: {nn_accuracy:.4f}")

# 4. 结果比较与可视化
plt.figure(figsize=(15, 10))

# 准确率对比
plt.subplot(2, 3, 1)
models = ['SVM', 'Neural Network']
accuracies = [svm_accuracy, nn_accuracy]
colors = ['skyblue', 'lightcoral']
bars = plt.bar(models, accuracies, color=colors)
plt.ylabel('Accuracy')
plt.title('Model Accuracy Comparison')
plt.ylim(0.8, 1.0)
for bar, acc in zip(bars, accuracies):
    plt.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.01, 
             f'{acc:.3f}', ha='center', va='bottom')

# 训练时间对比
plt.subplot(2, 3, 2)
train_times = [svm_train_time, nn_train_time]
bars = plt.bar(models, train_times, color=['lightgreen', 'gold'])
plt.ylabel('Time (seconds)')
plt.title('Training Time Comparison')
for bar, t in zip(bars, train_times):
    plt.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.01, 
             f'{t:.3f}s', ha='center', va='bottom')

# 预测时间对比
plt.subplot(2, 3, 3)
pred_times = [svm_pred_time, nn_pred_time]
bars = plt.bar(models, pred_times, color=['orange', 'purple'])
plt.ylabel('Time (seconds)')
plt.title('Prediction Time Comparison')
for bar, t in zip(bars, pred_times):
    plt.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.001, 
             f'{t:.4f}s', ha='center', va='bottom')

# SVM混淆矩阵
plt.subplot(2, 3, 4)
cm_svm = confusion_matrix(y_test, y_pred_svm)
plt.imshow(cm_svm, interpolation='nearest', cmap='Blues')
plt.title('SVM Confusion Matrix')
plt.colorbar()
plt.xticks([0, 1, 2], iris.target_names)
plt.yticks([0, 1, 2], iris.target_names)
plt.xlabel('Predicted Label')
plt.ylabel('True Label')
for i in range(3):
    for j in range(3):
        plt.text(j, i, str(cm_svm[i, j]), ha='center', va='center', color='white')

# 神经网络混淆矩阵
plt.subplot(2, 3, 5)
cm_nn = confusion_matrix(y_test, y_pred_nn)
plt.imshow(cm_nn, interpolation='nearest', cmap='Greens')
plt.title('Neural Network Confusion Matrix')
plt.colorbar()
plt.xticks([0, 1, 2], iris.target_names)
plt.yticks([0, 1, 2], iris.target_names)
plt.xlabel('Predicted Label')
plt.ylabel('True Label')
for i in range(3):
    for j in range(3):
        plt.text(j, i, str(cm_nn[i, j]), ha='center', va='center', color='white')

# 神经网络训练历史
plt.subplot(2, 3, 6)
plt.plot(history.history['accuracy'], label='Training Accuracy', linewidth=2)
plt.plot(history.history['val_accuracy'], label='Validation Accuracy', linewidth=2)
plt.xlabel('Epoch')
plt.ylabel('Accuracy')
plt.title('Neural Network Training History')
plt.legend()
plt.grid(True, alpha=0.3)

plt.tight_layout()
plt.show()

# 显示训练损失曲线
plt.figure(figsize=(8, 4))
plt.plot(history.history['loss'], label='Training Loss', linewidth=2)
plt.plot(history.history['val_loss'], label='Validation Loss', linewidth=2)
plt.xlabel('Epoch')
plt.ylabel('Loss')
plt.title('Neural Network Loss History')
plt.legend()
plt.grid(True, alpha=0.3)
plt.show()

# 5. 详细结果输出
print("\n详细分类结果:")
print("SVM分类报告:")
print(classification_report(y_test, y_pred_svm, target_names=iris.target_names))

print("\n神经网络分类报告:")
print(classification_report(y_test, y_pred_nn, target_names=iris.target_names))

print("\n模型效率对比总结:")
print(f"训练时间: SVM({svm_train_time:.3f}s) vs NN({nn_train_time:.3f}s)")
print(f"预测时间: SVM({svm_pred_time:.4f}s) vs NN({nn_pred_time:.4f}s)")
print(f"准确率: SVM({svm_accuracy:.4f}) vs NN({nn_accuracy:.4f})")

# 结论
print("\n实验结论:")
if svm_accuracy > nn_accuracy:
    print("SVM在准确率上表现更好")
elif nn_accuracy > svm_accuracy:
    print("神经网络在准确率上表现更好")
else:
    print("两种模型准确率相同")

if svm_train_time < nn_train_time:
    print("SVM训练速度更快")
else:
    print("神经网络训练速度更快")

if svm_pred_time < nn_pred_time:
    print("SVM预测速度更快")
else:
    print("神经网络预测速度更快")