import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import GridSearchCV, KFold
from sklearn.metrics import make_scorer

# 数据文件路径
file_path = "回归预测.xlsx" 
# 读取数据
train_df = pd.read_excel(file_path, sheet_name=0, header=None)
test_df = pd.read_excel(file_path, sheet_name=1, header=None)

# 分离特征和目标
X_train = train_df.iloc[:, 0:31].values
y_train = train_df.iloc[:, 31].values
X_test = test_df.iloc[:, 0:31].values
y_test = test_df.iloc[:, 31].values

# 处理药物名称（类别编码）
le = LabelEncoder()
X_train[:, 30] = le.fit_transform(X_train[:, 30].astype(str))
X_test[:, 30] = le.transform(X_test[:, 30].astype(str))

# 平方和相对误差
def rsse_score(y_true, y_pred):
    sst = np.sum((y_true - np.mean(y_true)) ** 2)
    return ((y_true - y_pred) ** 2) / sst

# 自定义评分器
rsse_scorer = make_scorer(lambda y_true, y_pred: -np.mean(rsse_score(y_true, y_pred)), greater_is_better=True)

# 随机森林调参
rf_param_grid = {
    "n_estimators": [100, 200, 300],
    "max_depth": [None, 10, 20],
    "min_samples_split": [2, 5]
}
rf = RandomForestRegressor(random_state=42)
cv = KFold(n_splits=5, shuffle=True, random_state=42)
rf_grid = GridSearchCV(estimator=rf, param_grid=rf_param_grid, cv=cv, scoring=rsse_scorer, n_jobs=-1, verbose=1)
rf_grid.fit(X_train, y_train)

# 梯度提升树调参
gbr_param_grid = {
    "n_estimators": [100, 200],
    "learning_rate": [0.01, 0.1],
    "max_depth": [3, 5]
}
gbr = GradientBoostingRegressor(random_state=42)
gbr_grid = GridSearchCV(estimator=gbr, param_grid=gbr_param_grid, cv=cv, scoring=rsse_scorer, n_jobs=-1, verbose=1)
gbr_grid.fit(X_train, y_train)

# 选择最优模型
rf_best_score = -rf_grid.best_score_
gbr_best_score = -gbr_grid.best_score_
best_model = rf_grid.best_estimator_ if rf_best_score < gbr_best_score else gbr_grid.best_estimator_
print(f"\n最优模型：{type(best_model).__name__}")
print(f"最优超参：{best_model.get_params()}")

# 测试集预测与误差统计
y_pred = best_model.predict(X_test)
test_errors = rsse_score(y_test, y_pred)
rsse_mean = np.mean(test_errors)
rsse_var = np.var(test_errors)

print(f"平方和相对误差均值Mean of RSSE：{round(rsse_mean, 6)}")
print(f"平方和相对误差方差variance of RSSE：{round(rsse_var, 8)}")